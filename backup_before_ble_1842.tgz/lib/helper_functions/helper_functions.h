/* ***************************************************************
 * helper_functions.h - library containing genral use helper functions
 *
 *  C W Greenstreet, Ver2, 25Oct2026
 *    GPLv3 Licence
 *
 ** ************************************************************* */

#ifndef HELPER_FUNCTIONS_H
#define HELPER_FUNCTIONS_H

#if ARDUINO >= 100  // this if-else block manages depreciated versions of Arduino IDE
#include <Arduino.h>
#else
#include <WConstants.h>
#include <WProgram.h>
#include <pins_arduino.h>
#endif  // end if-block

extern long unsigned startCookTime_ms;

/******************************************************
// helper function prototypes
*******************************************************/
float convertDegFtoDegC(float tempDegF);
long unsigned getElapsedCookTime_ms();
float getCountMS(float tempMS);

#endif  // end header guard