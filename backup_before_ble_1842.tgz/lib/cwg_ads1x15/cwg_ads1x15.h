/* ***************************************************************
 * cwg_ads1x15.h - library to extend ads1x15 library functionality
 *   includes
 *    1) RobTillaart/ADS1X15 library, licenced under MIT Licence
 *         reference:  https://github.com/RobTillaart/ADS1X15
 *    2) Luis Llamas/Arduino-MedianFilter, licenced under Apache Licence 2.0
 *         reference:
 * https://github-com.translate.goog/luisllamasbinaburo/Arduino-MedianFilter?_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=en
 *
 *  C W Greenstreet, Ver2, 25Oct2026
 *    GPLv3 Licence
 *
 ** ************************************************************* */

#ifndef CWG_ADS1x15_H
#define CWG_ADS1x15_H

#if ARDUINO >= 100  // this if-else block manages depreciated versions of Arduino IDE
#include <Arduino.h>
#else
#include <WConstants.h>
#include <WProgram.h>
#include <pins_arduino.h>
#endif  // end if-block

/******************************************************
//   Required library
*******************************************************/
#include <ADS1X15.h>  // ADS1x15 I2C ADC device functionality

/******************************************************
// Class definition:
//   CWG_ADS1115 is child (derrived) class of public library ADS1x15::ADS1115
******************************************************/

class CWG_ADS1115 : public ADS1115 {
 public:
  // constructor: device address, and optionally the Wire interface (defaults to &Wire)
  CWG_ADS1115(uint8_t Address = ADS1115_ADDRESS, TwoWire* wire = &Wire) : ADS1115(Address, wire) {}
  virtual ~CWG_ADS1115() {}

  // methods (function):
  void initialise(uint8_t gainSetting, uint8_t modeSetting, uint8_t dataRateSetting);
  float getVoltageFactor_V();
  float getSensorValue_MedianFiltered_V(uint8_t pin, int windowSize);

  // true only if the device acknowledged on the bus during initialise()
  bool deviceFound() const { return deviceOk; }

 protected:
  bool deviceOk = false;  // set by initialise()
};

// ensure objects are visible everywhere (global)
extern CWG_ADS1115 ads1115;

//==============================================================================================
// For reference:
//  ADS1X15 ADCs do not take an external reference voltage but rely on an internal full scale
//   voltage (fsv) that is a function of the PGA gain setting - see table below
//
//  Also note that AD1015 is notionally 12 bit but only for full scale differential measurements
//     with the one bit used for sign (neg / positive)
//   When single shot, the ADS1115 ADC is effectively 11 bit (2^11 = 2048 measurements)
//  For example, using default 2/3x gain, 6.144V fsv / 2048 measurements = 0.003 or 3mV LSB
// -------------------------
// PGA gain settings, max Voltage and LSB (least significant bit)
//   taken from Adafruit ADS1x15 library, where bit = LSB
//                                                                ADS1115  ADS1115
//                                                                -------  -------
// ads.setGain(GAIN_TWOTHIRDS);  // 2/3x gain +/- 6.144V  1 bit = 3mV      0.1875mV (default)
// ads.setGain(GAIN_ONE);        // 1x gain   +/- 4.096V  1 bit = 2mV      0.125mV
// ads.setGain(GAIN_TWO);        // 2x gain   +/- 2.048V  1 bit = 1mV      0.0625mV
// ads.setGain(GAIN_FOUR);       // 4x gain   +/- 1.024V  1 bit = 0.5mV    0.03125mV
// ads.setGain(GAIN_EIGHT);      // 8x gain   +/- 0.512V  1 bit = 0.25mV   0.015625mV
// ads.setGain(GAIN_SIXTEEN);    // 16x gain  +/- 0.256V  1 bit = 0.125mV  0.0078125mV
//==============================================================================================

#endif  // end header guard