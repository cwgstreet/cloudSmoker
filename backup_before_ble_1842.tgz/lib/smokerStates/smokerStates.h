/* ***************************************************************
 * smokerStates.h - cloudSmoker state machine implementation routines
 *
 * See
 * https://github.com/cwgstreet/cloudSmoker/blob/470cf69b76abfa9f5d605230191536e27d5985e3/Images/CloudSmoker%20state%20diagram2.jpg
 * for cloudSmoker1 State Machine diagram (to be updated for cloudSmoker2)
 *
 * C W Greenstreet, cloudSmoker2, 1Jul26
 * Licence: GPLv3 (Licensed under the GNU GPLv3: Free to use and modify, but any public
 * distribution must also share the full source code under this same licence.)
 *
 *************************************************************** */

#ifndef SMOKER_STATES_H
#define SMOKER_STATES_H

#if ARDUINO >= 100  // this if-else block manages depreciated versions of Arduino IDE
#include <Arduino.h>
#else
#include <WConstants.h>
#include <WProgram.h>
#include <pins_arduino.h>
extern bool bleSerialEnabled;
#endif  // end if-block

// UPGRADED: Conditional include to handle the network stack swap cleanly
#ifdef ESP32
#include <WiFi.h>
#else
#include <ESP8266WiFi.h>
extern bool bleSerialEnabled;
#endif

// Prepare case names for cloudSmoker State Machine switch-case stucture
enum entryStates_t {
  splashScreen = 1,  // set enum 1 to 10 rather than default 0 for first element
  launchPad,
  changeSettings,
  setMeatDoneTemp,
  setPitTempTarget,
  setTempUnits,
  getTemp,
  txTemp,
  Sleep,
  bbqStatus,
  calProbeMenu,   // choose which probe to calibrate, or reset it
  calWaitIce,     // settling and capture at 0 degF
  calWaitBoil,    // reference temperature entry and capture at boiling
  calResult,      // show gain and offset, save or cancel
  railStatus,     // bench check: INA226 rail and stored rail voltage
  resumePrompt,   // interrupted cook found at boot: tap to resume, hold to restart
  meatTempMenu,   // list of present meat probes, then Back
  editMeatTarget,  // target editor for one meat probe, always entered in degF
  pitTempMenu,     // PIT Min, Max, Back
  editPitLimit,
  bankMenu,  // power bank settings: capacity and charge
  editBank,  // capacity or charge editor
  cookMenu,
  bleMenu    // BLE serial on or off
};

bool cookApplyOnBoot();

// smokerState type defined in implementation smokerState.cpp, hence extern keyword
extern entryStates_t smokerState;

// globals, defined in main
extern long unsigned startCookTime_ms;
extern long unsigned previousMillis;
extern long unsigned transmitInterval;
extern long unsigned previousDisplayMillis;
extern long unsigned displayInterval;

/******************************************************
// Helper function prototype:
*******************************************************/

// process_state() prototype
void processState(CWG_LCD& lcd);

extern bool bleSerialEnabled;
#endif  // end header guard